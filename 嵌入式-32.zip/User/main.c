#include "stm32f10x.h"
#include "Delay.h"
#include "OLED.h"
#include "DHT11.h"
#include "SERIAL.h"
#include "PWM.h"
DHT11_Data_TypeDef DHT11_Data;
uint8_t RxData;
uint8_t cha=0;
int speed1=500,speed2=8000;
float angle1=90,angle2=90,angle3=0;//angle1:90->135
int main(void)
{
	OLED_Init();
	Serial_Init();
	DHT11_GPIO_Config();
	PWM_Init();
	OLED_ShowString(1, 1, "temp:");
	OLED_ShowString(2, 1, "humidity:");
	
	while (1)
	{
		PWM_SetCompare3(1500);
		OLED_ShowNum(3,3,1,1);
		
		PWM_SetCompare31(speed1);
		PWM_SetCompare32(speed2);
		PWM_SetCompare3(angle2 / 180 * 2000 + 500);//2�Ŷ��
		PWM_SetCompare2(angle1 / 180 * 2000 + 500);//1�Ŷ��
		if(Read_DHT11(&DHT11_Data) == SUCCESS)//DHT��ȡ�¶�ʪ��
		{
			OLED_ShowNum(2, 10, DHT11_Data.humi_int, 2);
			OLED_ShowString(2, 12, ".");
			OLED_ShowNum(2, 13, DHT11_Data.humi_deci, 2);
			
			OLED_ShowNum(1, 6, DHT11_Data.temp_int, 2);
			OLED_ShowString(1, 8, ".");
			OLED_ShowNum(1, 9, DHT11_Data.temp_deci, 1);
			
		}
		if(cha==1)//��������
		{
			cha=0;
			for(float i=90;i<135;i++)
			{
				PWM_SetCompare2(i / 180 * 2000 + 500);
				Delay_ms(30);
			}
			PWM_SetCompare2(angle1 / 180 * 2000 + 500);
		}
		Serial_SendByte(0x00);
		Serial3_Printf("TEMP��%d",DHT11_Data.temp_int);
		Serial3_Printf("HUMI��%d",DHT11_Data.humi_int);
		OLED_ShowNum(3,1,0,1);
		
		Serial_SendByte(0x01);
		OLED_ShowNum(3,1,1,1);
		Serial3_Printf("TEMP��%d",DHT11_Data.temp_int);
		Serial3_Printf("HUMI��%d",DHT11_Data.humi_int);
		OLED_ShowNum(3,3,0,1);
		OLED_ShowNum(4,1,angle1,3);//��ʾ��ʼ�Ƕ�
		OLED_ShowNum(4,5,angle2,3);
		Delay_ms(100);
	}
}
